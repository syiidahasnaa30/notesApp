import React from "react";

const EmptyNoteList = () => {
  return (
    <div className="notes-list-empty">
      <p>Your Note is Empty</p>
    </div>
  );
};

export default EmptyNoteList;
