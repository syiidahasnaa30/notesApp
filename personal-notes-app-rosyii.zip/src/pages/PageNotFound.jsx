import React from "react";

const PageNotFound = () => {
  return (
    <div className="notes-list-empty">
      <h2>Page Not Found</h2>
    </div>
  );
};

export default PageNotFound;
